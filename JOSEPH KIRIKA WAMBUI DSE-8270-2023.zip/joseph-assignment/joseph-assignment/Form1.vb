﻿Public Class Form1
    Private Sub btnCompute_Click(sender As Object, e As EventArgs) Handles btnCompute.Click
        Dim chemMarks As Double
        Dim phyMarks As Double
        Dim oopMarks As Double

        Try
            chemMarks = Double.Parse(txtChem.Text)
            phyMarks = Double.Parse(txtPhy.Text)
            oopMarks = Double.Parse(txtOop.Text)












        Catch ex As Exception
            MessageBox.Show("invalid input", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)



        End Try

        Dim totalGrade = chemMarks + phyMarks + oopMarks
        Dim averageGrade = totalGrade / 3


        lblTotal.Text = totalGrade.ToString("0.00")
        lblAverage.Text = averageGrade.ToString("0.00")

        Dim grade As String
        If averageGrade >= 90 Then
            grade = "A"

        ElseIf averageGrade >= 80 Then
            grade = "B"

        ElseIf averageGrade >= 70 Then
            grade = "C"

        ElseIf averageGrade >= 60 Then
            grade = "D"

        ElseIf averageGrade >= 50 Then
            grade = "D-"

        ElseIf averageGrade >= 40 Then
            grade = "E"

        Else
            grade = "F"

        End If
        lblGrade.Text = grade









    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtChem.Clear()
        txtPhy.Clear()
        txtOop.Clear()

        lblTotal.Text = ""
        lblAverage.Text = ""
        lblGrade.Text = ""
        txtChem.Focus()






    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
