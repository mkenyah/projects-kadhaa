﻿Public Class Form1
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim operand1 As Double, operand2 As Double, btnAdd As Double
        operand1 = Val(txtOperand1.Text)
        operand2 = Val(txtOperand2.Text)

        btnAdd = operand1 + operand2

        lblResults.Text = btnAdd.ToString









    End Sub

    Private Sub btnSub_Click(sender As Object, e As EventArgs) Handles btnSub.Click
        Dim operand1 As Double, operand2 As Double, btnSub As Double
        operand1 = Val(txtOperand1.Text)
        operand2 = Val(txtOperand2.Text)

        btnSub = operand1 - operand2

        lblResults.Text = btnSub.ToString

    End Sub

    Private Sub btnMult_Click(sender As Object, e As EventArgs) Handles btnMult.Click

        Dim operand1 As Double, operand2 As Double, btnMult As Double
        operand1 = Val(txtOperand1.Text)
        operand2 = Val(txtOperand2.Text)

        btnMult = operand1 * operand2

        lblResults.Text = btnMult.ToString
    End Sub

    Private Sub btnDiv_Click(sender As Object, e As EventArgs) Handles btnDiv.Click
        Dim operand1 As Double, operand2 As Double, btnDiv As Double
        operand1 = Val(txtOperand1.Text)
        operand2 = Val(txtOperand2.Text)

        If operand2 <> 0 Then
            btnDiv = operand1 / operand2
            lblResults.Text = btnDiv.ToString()
        Else
            lblResults.Text = "Cannot divide by zero"
        End If

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click

        txtOperand1.Clear()
        txtOperand2.Clear()
        lblResults.Text = ""
        txtOperand1.Focus()



    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub

    Private Sub btnMode_Click(sender As Object, e As EventArgs) Handles btnMode.Click


        Dim operand1 As Single
        Dim operand2 As Single


        If Single.TryParse(txtOperand1.Text, operand1) AndAlso Single.TryParse(txtOperand2.Text, operand2) Then
            If operand1 = operand2 Then
                lblResults.Text = operand1.ToString() & " and " & operand2.ToString()


            ElseIf operand1 = operand2 Then
                lblResults.Text = "Result: 1"
                Else
                lblResults.Text = operand1.ToString() & " and " & operand2.ToString()


            End If
        Else

            MessageBox.Show("Please enter valid numeric values for Operand 1 and Operand 2.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If


    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles btnBackslash.Click
        Try
            Dim operand1 As Double = Convert.ToDouble(txtOperand1.Text)
            Dim operand2 As Double = Convert.ToDouble(txtOperand2.Text)

            Dim result As String = DecimalToFraction(operand1 / operand2)
            lblResults.Text = result
        Catch ex As FormatException
            lblResults.Text = "Invalid input. Please enter valid numbers."
        End Try
    End Sub

    Private Function DecimalToFraction(decimalValue As Double) As String
        Dim tolerance As Double = 0.0001
        Dim numerator As Integer = 1
        Dim denominator As Integer = 1

        While Math.Abs(decimalValue - CDbl(numerator) / CDbl(denominator)) > tolerance
            If decimalValue > CDbl(numerator) / CDbl(denominator) Then
                numerator += 1
            Else
                denominator += 1
            End If
        End While

        Return $"{numerator}\{denominator}"
    End Function


End Class
