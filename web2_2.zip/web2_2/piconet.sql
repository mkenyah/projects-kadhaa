-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 15, 2024 at 02:56 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `piconet`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `fname` varchar(50) DEFAULT NULL,
  `lname` varchar(50) DEFAULT NULL,
  `gender` enum('male','female') DEFAULT NULL,
  `contact` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `services` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `fname`, `lname`, `gender`, `contact`, `email`, `services`) VALUES
(11, 'Joseph', 'kirika', 'male', '09324', 'kirikajoseph16@gmail.com', 'services2'),
(12, 'Joseph', 'kirika', 'female', '4568', 'kirikajoseph16@gmail.com', 'services2'),
(13, 'Shawn', 'karuu', 'male', '78767', 'shawnk@gmail.com', 'services4'),
(14, 'susan', 'mugure', 'female', '074746993', 'susanm@gmail.com', 'services2'),
(15, 'clare', 'wangui', 'female', '00789876', 'clarew@gmail.com', 'services3'),
(16, 'clare', 'wangui', 'female', '00789876', 'clarew@gmail.com', 'services3'),
(17, 'clare', 'wangui', 'female', '00789876', 'clarew@gmail.com', 'services3'),
(18, 'clare', 'wangui', 'female', '00789876', 'clarew@gmail.com', 'services3'),
(19, 'clare', 'wangui', 'female', '00789876', 'clarew@gmail.com', 'services3'),
(20, 'clare', 'wangui', 'female', '00789876', 'clarew@gmail.com', 'services3'),
(21, 'clare', 'wangui', 'female', '00789876', 'clarew@gmail.com', 'services3'),
(22, 'clare', 'wangui', 'female', '00789876', 'clarew@gmail.com', 'services3'),
(23, 'clare', 'wangui', 'female', '00789876', 'clarew@gmail.com', 'services3'),
(24, 'clare', 'wangui', 'female', '00789876', 'clarew@gmail.com', 'services3'),
(25, 'clare', 'wangui', 'female', '00789876', 'clarew@gmail.com', 'services3'),
(26, 'clare', 'wangui', 'female', '00789876', 'clarew@gmail.com', 'services3'),
(27, 'clare', 'wangui', 'female', '00789876', 'clarew@gmail.com', 'services3'),
(28, 'Ezekiel', 'kungu', 'male', '08659876', 'ezekielk@gmail.com', 'services1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
