<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PICONET TECHNOLOGY</title>
    <style>
        form{
            background-color: white;
            text-align: center;
            width: 270px;
            height: 85vh;
            border: 1px solid blue;
            box-shadow: 5px 10px blueviolet;
            color: blue;

            margin-left: auto;
            margin-right: auto;
            border-radius: 20px;
            font-family: Verdana, Geneva, Tahoma, sans-serif;
            font-size: 15px;
        }
     form   h1{
            text-align: center;
            color: blue;
        }

        input{
            margin: 2px;
            width: 190px;
            height: 5vh;
            border-radius: 15px;
            border-top: 1px solid blueviolet;
            border-bottom: 1px solid blue;
            border-left: 1px solid blueviolet;
            border-right: 1px solid blueviolet;
            text-align: center;
        }
        ::placeholder{
            font-family: Verdana, Geneva, Tahoma, sans-serif;
            text-align: center;
            color: grey;

        }
    </style>
</head>
<body>
    <form action="process.php" method="post">
        <h3>PICONET_TECHNLOGY</h3>
        <input type="text" name="fname" placeholder="FIRST_NAME" required>
        <input type="text" name="lname" placeholder="LAST_NAME" required>
        <input type="tel" name="contact" placeholder="CONTACT" required>
        <input type="email" name="email" placeholder="EMAIL" required>

        <input type="radio" name="gender" value="male" required>
       <label >male</label>

        <input type="radio" name="gender" value="female" required>
        <label >female</label>

        <input type="checkbox" name="services[]" value="services1">
        <label>service1</label>

        <input type="checkbox" name="services[]" value="services2" >
        <label >service2</label>

        <input type="checkbox" name="services[]" value="services3">
        <label >service3</label>

        <input type="checkbox" name="services[]" value="services4" >
        <label >service4</label>

        <input type="submit" name="submit" value="SUBMIT">
    </form>
</body>
</html>