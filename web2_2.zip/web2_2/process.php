<?php
if(isset($_POST['submit'])){

$fname = $_POST['fname'];
$lname = $_POST['lname'];
$gender = $_POST['gender'];
$contact = $_POST['contact'];
$email = $_POST['email'];
$service = implode(",",$_POST['services']);

$host = "localhost";
$username = "root";
$password = "";
$dbname = "piconet";

$conn = new mysqli($host, $username ,$password, $dbname );

if($conn){
   

    $sql = "INSERT INTO users (fname, lname, gender, contact, email, services) VALUES ('$fname', '$lname', '$gender', '$contact', '$email', '$service')";
        $result = mysqli_query($conn, $sql);

    if($result){
        echo"<h3 style='color:blue;'>Data inserted successfully✔✔</h3> ";
        
    }else{
        echo"The data was not installed";
    }

}else{
    die(mysqli_error($conn));
}

}
echo'<a href="./form.php">Back home</a>';
?>