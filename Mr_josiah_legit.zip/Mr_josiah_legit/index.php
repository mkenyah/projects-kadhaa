<?php
$host = "localhost";
$username = "root";
$password = "";
$dbname = "oxygen";

$conn = new mysqli($host, $username, $password, $dbname);
if($conn->connect_error){
    die("connection failed:". $conn->connect_error);
}

if($_SERVER['REQUEST_METHOD'] == 'POST' ){
    //ORDER
    $customer_id = $_POST['customer_id'] ?? '';
    $order_date = $_POST['order_date'] ?? '';
    $status = $_POST['status']  ?? '';

    //PROFILE 
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $phone_number = $_POST['phone_number'] ?? '';
    $address = $_POST['address'] ?? '';

$sql = "INSERT INTO orders(customer_id, order_date, status) VALUES(?, ?, ?)";
$stmt = $conn->prepare($sql);
// $stmt = mysqli_query($conn,$sql);
$stmt->bind_param("ssi",$customer_id, $order_date, $status);
if ($stmt->execute()){
    echo"order inserted successfully";
}else{
    echo"An error occured when inserting the data: ". $stmt->error;
}

//profiles
$sql = "INSERT INTO profiles(name, email, phone_number, address) VALUES(?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
// $stmt = mysqli_query($conn,$sql);
$stmt->bind_param("ssss",$name, $email, $phone_number, $address);
if ($stmt->execute()){
    echo"order inserted successfully";
}else{
    echo"An error occured when inserting the data: ". $stmt->error;
}


}




$conn->close();

   ?>
 






